object ArrayDemo {
  
  def mySquare(arr: Array[Int]): Array[Int] = {
    
    arr.map(elem => elem * elem)
    
  } 
  
  
  def myCube(arr: Array[Int]): Array[Int] = {
  
    arr.map(elem => elem*elem*elem)
  
  }

  
  def main(args: Array[String]) {
    println("This is ArrayDemo!")
    
    
    val vector = Array.fill(10){scala.util.Random.nextInt(9)} 
    
    println(vector.mkString(","))
    println(mySquare(vector).mkString(","))
    println(myCube(vector).mkString(","))
    
  }
}
