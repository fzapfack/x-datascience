object QuickSort {
  
  def quick(xs: Array[Int]): Array[Int] = {
    
    if (xs.length <= 1) xs
    else {
      val pivot = xs(xs.length / 2)
      Array.concat(quick(xs filter (_ < pivot)), xs filter (_ == pivot), quick(xs filter (_ > pivot)))
    }
  } 

  
  def main(args: Array[String]) {
    println("This is QuickSort!")
    
    val nums = Array(5,2,1,9,8,4,6) 
    
    println(nums.mkString(",")) // display the unordered array
    
    println("Sorting array ...") 
    val sortednums = quick(nums) // sort the array by calling bubble
    println("sorting done.")
    
    println(sortednums.mkString(",")) // display the ordered array
    
  }
}
