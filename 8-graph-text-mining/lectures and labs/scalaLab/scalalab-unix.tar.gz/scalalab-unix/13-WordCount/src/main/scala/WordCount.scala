/* WordCount.scala */

import scala.io.Source

object WordCount {
  def main(args: Array[String]) {
       
   val counts = scala.io.Source.fromFile("leonardo.txt").
      getLines().
      flatMap(_.split("\\W+")).
      foldLeft(Map.empty[String, Int]){
      (count, word) => count + (word -> (count.getOrElse(word, 0) + 1))
    }
    
    counts.toSeq.sortBy(_._1).foreach(println)
  }
}


