/* WordCount.scala */

import scala.io.Source

object WordCount {
  def main(args: Array[String]) {
    
    val lines = Source.fromFile("leonardo.txt").getLines.toArray
    
    val counts = new collection.mutable.HashMap[String, Int].withDefaultValue(0)
    
    lines.flatMap(line => line.split(" ")).foreach(word => counts(word) += 1)
    
    println(counts)
          
  }
}


