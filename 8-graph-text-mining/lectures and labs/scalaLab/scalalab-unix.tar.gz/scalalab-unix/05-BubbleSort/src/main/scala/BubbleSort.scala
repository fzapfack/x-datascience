object BubbleSort {
  
  def bubble(nums: Array[Double]) {
  
    println("Sorting array ...") 
    
    for (i <- 0 until nums.length - 1) {
      for (j <- 0 until nums.length - 1 - i) {
	if (nums(j) > nums(j+1)) { // swap
	  val tmp = nums(j)
	  nums(j) = nums(j+1)
	  nums(j+1) = tmp
	}
      }
    }
    
    println("sorting done.")
  }
  
  
  def main(args: Array[String]) {
    println("This is BubbleSort!")
    
    val nums = Array.fill(10)(math.random)  // create an array of random numbers
    
    println(nums.mkString(",")) // display the unordered array
    
    bubble(nums) // sort the array by calling bubble
    
    println(nums.mkString(",")) // display the ordered array
    
  }
  
}
