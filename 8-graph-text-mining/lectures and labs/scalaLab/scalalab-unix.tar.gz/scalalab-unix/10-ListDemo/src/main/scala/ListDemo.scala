object ListDemo {
  
  def main(args: Array[String]) {
  
    println("This is ListDemo!")
    
    val lst = List(1,7,2,8,5,6,3,9,14,12,4,10)
    
    println(lst.mkString(","))
  
  }
  
}
