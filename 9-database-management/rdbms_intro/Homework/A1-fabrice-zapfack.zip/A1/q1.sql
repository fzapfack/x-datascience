SELECT DISTINCT S.sname, S.address
	FROM suppliers S, catalog C
	WHERE S.sid = C.sid
	ORDER BY S.sname, S.address ;
