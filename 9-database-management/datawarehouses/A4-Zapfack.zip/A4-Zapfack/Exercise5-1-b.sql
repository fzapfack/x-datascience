SELECT year, sum(publi) as spubli
FROM yearPublish 
GROUP BY year
ORDER BY spubli DESC
LIMIT 10;







